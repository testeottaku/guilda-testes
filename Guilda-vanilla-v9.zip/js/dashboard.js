import "./firebase.js";

function card({title,value,icon,color,bgLight,textColor}){
  return `
    <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
      <div class="flex items-start justify-between mb-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center shadow-lg shadow-emerald-200/40 text-white">
          <i data-lucide="${icon}" class="w-5 h-5"></i>
        </div>
      </div>
      <div>
        <p class="text-3xl font-bold text-gray-900">${value}</p>
        <p class="text-sm text-gray-500 mt-1">${title}</p>
      </div>
    </div>
  `;
}

function attentionItem(label, val, dot, color){
  return `
    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
      <div class="flex items-center gap-2">
        <div class="w-2 h-2 rounded-full ${dot}"></div>
        <span class="text-sm ${color}">${label}</span>
      </div>
      <span class="text-sm font-bold ${color}">${val}</span>
    </div>
  `;
}

function barItem(label, val, max, fromC, toC){
  const pct = max>0 ? Math.round((val/max)*100) : 0;
  return `
    <div>
      <div class="flex items-center justify-between mb-1">
        <span class="text-sm text-gray-600">${label}</span>
        <span class="text-sm font-semibold text-gray-900">${pct}%</span>
      </div>
      <div class="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
        <div class="h-full bg-gradient-to-r ${fromC} ${toC} rounded-full" style="width:${pct}%"></div>
      </div>
    </div>
  `;
}

async function init(){
  // role gate already ran in shell script, but ensure session exists
  if(!window.__session) return;

  const loading = document.getElementById("loading");
  const stats = document.getElementById("stats-grid");
  const details = document.getElementById("details-grid");
  try{
    const members = await window.__guildDB.getMembers();

    const total = members.length;
    const gw = members.filter(m=>m.guildWar).length;
    const meta = members.filter(m=>m.weeklyMeta).length;
    const tag = members.filter(m=>m.hasTag).length;

    stats.innerHTML = [
      card({title:"Total de Membros", value: total, icon:"users", color:"from-emerald-500 to-green-600"}),
      card({title:"Guerra de Guilda", value: gw, icon:"swords", color:"from-blue-500 to-indigo-600"}),
      card({title:"Meta Semanal", value: meta, icon:"target", color:"from-violet-500 to-purple-600"}),
      card({title:"Com Tag", value: tag, icon:"tag", color:"from-amber-500 to-orange-600"})
    ].join("");

    document.getElementById("attention-list").innerHTML = [
      attentionItem("Sem Guerra de Guilda", total-gw, "bg-red-500", "text-red-700"),
      attentionItem("Meta Pendente", total-meta, "bg-orange-500", "text-orange-700"),
      attentionItem("Sem Tag", total-tag, "bg-gray-400", "text-gray-600")
    ].join("");

    document.getElementById("summary-bars").innerHTML = [
      barItem("Participação na Guerra", gw, total, "from-emerald-400", "to-green-500"),
      barItem("Meta Semanal Cumprida", meta, total, "from-violet-400", "to-purple-500"),
      barItem("Membros com Tag", tag, total, "from-amber-400", "to-orange-500")
    ].join("");

    loading.classList.add("hidden");
    stats.classList.remove("hidden");
    stats.classList.add("grid");
    details.classList.remove("hidden");
    details.classList.add("grid");

    lucide.createIcons();
  }catch(e){
    console.error(e);
    window.__toast && window.__toast("error","Erro ao carregar dados.");
  }
}

document.addEventListener("DOMContentLoaded", init);
