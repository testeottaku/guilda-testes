import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
  getFirestore,
  collection,
  getDoc,
  getDocs,
  setDoc,
  doc,
  deleteDoc,
  serverTimestamp,
  query,
  where,
  limit
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA5uana2jcnWCkY3vqpotbpoQKxy7bTMtU",
  authDomain: "guilda-otk.firebaseapp.com",
  projectId: "guilda-otk",
  storageBucket: "guilda-otk.firebasestorage.app",
  messagingSenderId: "628349020809",
  appId: "1:628349020809:web:be1457404159f9ea2a3458",
  measurementId: "G-65FGV5MT0N"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

function toast(type, msg, ms){
  try{ window.__toast && window.__toast(type, msg, ms); }catch(_){}
}

async function getSecurity(){
  const snap = await getDoc(doc(db, "guildConfig", "security"));
  const data = snap.exists() ? snap.data() : {};
  return {
    admins: Array.isArray(data.admins) ? data.admins.map(e => String(e).toLowerCase().trim()) : [],
    leaders: Array.isArray(data.leaders) ? data.leaders.map(e => String(e).toLowerCase().trim()) : []
  };
}

async function ensureRole(user){
  const u = user || auth.currentUser;
  if(!u || !u.email) return null;
  const sec = await getSecurity();
  const email = String(u.email).toLowerCase().trim();
  const role = sec.admins.includes(email) ? "admin" : (sec.leaders.includes(email) ? "leader" : null);
  if(!role) return null;
  const session = { email, role };
  window.__session = session;
  try{ sessionStorage.setItem("__session", JSON.stringify(session)); }catch(_){}
  return session;
}

async function requireAuth({ allowRoles = ["admin","leader"], redirectTo = "index.html" } = {}){
  return new Promise((resolve) => {
    onAuthStateChanged(auth, async (user) => {
      if(!user){
        window.__session = null;
        try{ sessionStorage.removeItem("__session"); }catch(_){}
        window.location.href = redirectTo;
        resolve(null);
        return;
      }
      const s = await ensureRole(user);
      if(!s || !allowRoles.includes(s.role)){
        toast("error","Acesso negado.");
        try{ await signOut(auth); }catch(_){}
        window.location.href = redirectTo;
        resolve(null);
        return;
      }
      resolve({ user, session: s });
    });
  });
}

// ---- DB: MEMBROS ----
async function getMembers(){
  const snap = await getDocs(collection(db, "membros"));
  const arr = [];
  snap.forEach(d => arr.push({ id: d.id, ...d.data() }));
  arr.sort((a,b)=>String(a.nick||"").localeCompare(String(b.nick||""), "pt-BR", {sensitivity:"base"}));
  return arr;
}

async function addMember(member){
  // valida ID duplicado (visibleId)
  if(member.visibleId){
    const q = query(collection(db, "membros"), where("visibleId","==", String(member.visibleId)), limit(1));
    const s = await getDocs(q);
    if(!s.empty) throw new Error("ID já existe!");
  }
  const id = member.id || doc(collection(db,"membros")).id;
  const payload = { ...member, id, updatedAt: serverTimestamp() };
  await setDoc(doc(db, "membros", id), payload, { merge: false });
  return id;
}

async function updateMember(id, data){
  const payload = { ...data, updatedAt: serverTimestamp() };
  await setDoc(doc(db, "membros", id), payload, { merge: true });
}

async function deleteMember(id){
  await deleteDoc(doc(db, "membros", id));
}

// ---- ADMIN: SECURITY LISTS ----
async function setSecurity({admins, leaders}){
  const payload = {
    admins: (admins||[]).map(e=>String(e).toLowerCase().trim()),
    leaders: (leaders||[]).map(e=>String(e).toLowerCase().trim()),
    updatedAt: serverTimestamp()
  };
  await setDoc(doc(db, "guildConfig", "security"), payload, { merge: true });
  return payload;
}

async function createAccount(email, password){
  // OBS: só funciona se o projeto permitir (muitas vezes exige Admin SDK).
  // Mantemos igual ao v9 (client-side). Se falhar, exibimos erro amigável.
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  return cred.user;
}

// ---- API Mitsuri ----
const MITSURI_URL = "https://api.mitsuri.fun/api/trpc/api.info";
const MITSURI_KEY = "mitsuri_UVPRYNm5RNdvirmjrMQqlu8XVpEpFPxP";

async function fetchMitsuri(uid, region="BR"){
  const res = await fetch(MITSURI_URL, {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ json: { key: MITSURI_KEY, uid: String(uid), region } })
  });
  const json = await res.json();
  return json?.result?.data?.json || null;
}

// Expor
window.__firebase = { app, db, auth };
window.__adminApi = { getSecurity, setSecurity, ensureRole, requireAuth, signOut: ()=>signOut(auth), signIn: (e,p)=>signInWithEmailAndPassword(auth,e,p), createAccount };
window.__guildDB = { getMembers, addMember, updateMember, deleteMember, fetchMitsuri };

