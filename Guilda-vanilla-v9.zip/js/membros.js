import "./firebase.js";

let cache = [];
let editingId = null;

function el(id){ return document.getElementById(id); }

function memberRow(m){
  const first = (m.nick || "?").trim().charAt(0).toUpperCase();
  const gwIcon = m.guildWar ? `<i data-lucide="swords" class="w-4 h-4 text-emerald-500"></i>` : `<i data-lucide="swords" class="w-4 h-4 text-gray-300"></i>`;
  const metaIcon = m.weeklyMeta ? `<i data-lucide="target" class="w-4 h-4 text-violet-500"></i>` : `<i data-lucide="target" class="w-4 h-4 text-gray-300"></i>`;
  const tagVal = m.hasTag ? `<i data-lucide="check" class="w-4 h-4 text-emerald-500"></i>` : `<i data-lucide="x" class="w-4 h-4 text-red-400"></i>`;
  const wa = m.whatsapp ? `
    <a href="https://wa.me/55${m.whatsapp}" target="_blank" rel="noopener noreferrer"
      class="flex items-center gap-1 text-emerald-600 text-xs hover:underline"
      onclick="event.stopPropagation()">
      <i data-lucide="phone" class="w-3 h-3"></i>${m.whatsapp}
    </a>` : `<span class="text-xs text-gray-400">—</span>`;

  return `
  <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden transition-all hover:shadow-md" data-id="${m.id}">
    <div class="p-4 flex items-center gap-3 cursor-pointer" data-toggle>
      <div class="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-green-500 flex items-center justify-center text-white font-bold text-sm">${first}</div>
      <div class="flex-1 min-w-0">
        <p class="font-semibold text-gray-900 text-sm truncate">${m.nick || "—"}</p>
        <p class="text-xs text-gray-400">ID: ${m.visibleId || "—"}</p>
      </div>
      <div class="flex gap-2">${gwIcon}${metaIcon}</div>
      <i data-lucide="chevron-down" class="w-4 h-4 text-gray-300 transition-transform" data-chevron></i>
    </div>

    <div class="hidden bg-gray-50 border-t border-gray-100 p-4 space-y-3 text-sm" data-details>
      <div class="grid grid-cols-2 gap-2">
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Guerra</p>
          <div class="flex items-center gap-2">
            ${m.guildWar ? `<span class="text-sm font-semibold text-gray-900">Sim</span>` : `<span class="text-sm font-semibold text-gray-900">Não</span>`}
            <span class="text-xs text-gray-400">(${Number(m.guildWarMeta || 0)})</span>
          </div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Meta Semanal</p>
          <div class="flex items-center gap-2">
            ${m.weeklyMeta ? `<span class="text-sm font-semibold text-gray-900">Sim</span>` : `<span class="text-sm font-semibold text-gray-900">Não</span>`}
            <span class="text-xs text-gray-400">(${Number(m.weeklyMetaValue || 0)})</span>
          </div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Tag</p>
          <div class="flex items-center gap-2">${tagVal}<span class="text-xs text-gray-500">${m.hasTag ? "Sim" : "Não"}</span></div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">WhatsApp</p>
          ${wa}
        </div>
      </div>

      <div class="flex gap-2">
        <button class="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-100 text-emerald-700 text-sm font-medium hover:bg-emerald-200 transition-colors flex-1" data-edit>
          <i data-lucide="pencil" class="w-4 h-4"></i> Editar
        </button>
        <button class="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-100 text-red-700 text-sm font-medium hover:bg-red-200 transition-colors flex-1" data-delete>
          <i data-lucide="trash-2" class="w-4 h-4"></i> Excluir
        </button>
      </div>
    </div>
  </div>`;
}

function render(list){
  const box = el("members-list");
  if(!box) return;
  if(!list.length){
    box.innerHTML = `<div class="bg-white rounded-2xl p-8 border border-gray-100 text-center text-gray-400">Nenhum membro encontrado.</div>`;
    lucide.createIcons();
    return;
  }
  box.innerHTML = list.map(memberRow).join("");
  box.querySelectorAll("[data-toggle]").forEach(row=>{
    row.addEventListener("click", () => {
      const card = row.closest("[data-id]");
      const details = card.querySelector("[data-details]");
      const chev = card.querySelector("[data-chevron]");
      const open = !details.classList.contains("hidden");
      if(open){
        details.classList.add("hidden");
        chev.style.transform = "rotate(0deg)";
      }else{
        details.classList.remove("hidden");
        chev.style.transform = "rotate(180deg)";
      }
    });
  });
  box.querySelectorAll("[data-edit]").forEach(btn=>{
    btn.addEventListener("click", (ev)=>{
      ev.stopPropagation();
      const id = btn.closest("[data-id]").getAttribute("data-id");
      openModal(id);
    });
  });
  box.querySelectorAll("[data-delete]").forEach(btn=>{
    btn.addEventListener("click", async (ev)=>{
      ev.stopPropagation();
      const id = btn.closest("[data-id]").getAttribute("data-id");
      await doDelete(id);
    });
  });
  lucide.createIcons();
}

async function load(){
  el("members-list").innerHTML = `<p class="text-center text-gray-400 py-10">Carregando membros...</p>`;
  try{
    cache = await window.__guildDB.getMembers();
    render(cache);
  }catch(e){
    console.error(e);
    window.__toast && window.__toast("error","Erro ao carregar membros.");
  }
}

function filter(){
  const term = (el("search-input").value||"").toLowerCase().trim();
  if(!term){ render(cache); return; }
  const f = cache.filter(m => String(m.nick||"").toLowerCase().includes(term) || String(m.visibleId||"").includes(term));
  render(f);
}

// Modal
function showModal(v){
  const modal = el("modal");
  if(!modal) return;
  modal.classList.toggle("hidden", !v);
  if(v) lucide.createIcons();
}

function setModalTitle(t){ const tt=el("modal-title"); if(tt) tt.textContent=t; }

function fillForm(m){
  el("inp-visibleId").value = m?.visibleId || "";
  el("inp-nick").value = m?.nick || "";
  el("inp-whatsapp").value = m?.whatsapp || "";
  el("inp-guildWar").checked = !!m?.guildWar;
  el("inp-guildWarMeta").value = Number(m?.guildWarMeta || 0);
  el("inp-weeklyMeta").checked = !!m?.weeklyMeta;
  el("inp-weeklyMetaValue").value = Number(m?.weeklyMetaValue || 0);
  el("inp-hasTag").checked = !!m?.hasTag;
  const msg = el("api-msg");
  if(msg){ msg.classList.add("hidden"); msg.textContent=""; }
}

function openModal(id=null){
  editingId = id;
  const member = id ? cache.find(x=>x.id===id) : null;
  setModalTitle(id ? "Editar Membro" : "Novo Membro");
  fillForm(member);
  showModal(true);
}

function closeModal(){ showModal(false); editingId=null; }

async function fetchMitsuri(){
  const uid = (el("inp-visibleId").value||"").trim();
  if(!uid) return;
  const msg = el("api-msg");
  msg.className = "text-xs mt-1 text-gray-500 block";
  msg.textContent = "Buscando...";
  try{
    const data = await window.__guildDB.fetchMitsuri(uid, "BR");
    if(data && data.nickname){
      el("inp-nick").value = data.nickname;
      msg.className = "text-xs mt-1 text-emerald-600 block";
      msg.textContent = `Encontrado: ${data.nickname} (Nvl ${data.level})`;
    }else{
      msg.className = "text-xs mt-1 text-red-500 block";
      msg.textContent = "Jogador não encontrado.";
    }
  }catch(e){
    msg.className = "text-xs mt-1 text-red-500 block";
    msg.textContent = "Erro na API.";
  }
}

async function doSave(e){
  e.preventDefault();
  const data = {
    visibleId: (el("inp-visibleId").value||"").trim(),
    nick: (el("inp-nick").value||"").trim(),
    whatsapp: (el("inp-whatsapp").value||"").trim(),
    guildWar: el("inp-guildWar").checked,
    guildWarMeta: Number(el("inp-guildWarMeta").value || 0),
    weeklyMeta: el("inp-weeklyMeta").checked,
    weeklyMetaValue: Number(el("inp-weeklyMetaValue").value || 0),
    hasTag: el("inp-hasTag").checked
  };
  if(!data.visibleId || !data.nick){
    window.__toast && window.__toast("error","Preencha ID e Nick.");
    return;
  }
  try{
    if(editingId){
      await window.__guildDB.updateMember(editingId, { id: editingId, ...data });
      window.__toast && window.__toast("success","Atualizado!");
    }else{
      await window.__guildDB.addMember(data);
      window.__toast && window.__toast("success","Adicionado!");
    }
    closeModal();
    await load();
  }catch(err){
    window.__toast && window.__toast("error", err?.message || "Erro ao salvar.");
  }
}

async function doDelete(id){
  if(!confirm("Tem certeza que deseja excluir?")) return;
  try{
    await window.__guildDB.deleteMember(id);
    window.__toast && window.__toast("success","Excluído!");
    await load();
  }catch(e){
    window.__toast && window.__toast("error","Erro ao excluir.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  // wire buttons
  const btnAdd = el("btn-add");
  btnAdd && btnAdd.addEventListener("click", ()=>openModal(null));
  el("btn-close-modal")?.addEventListener("click", closeModal);
  el("modal-overlay")?.addEventListener("click", closeModal);
  el("btn-mitsuri")?.addEventListener("click", fetchMitsuri);
  el("member-form")?.addEventListener("submit", doSave);
  el("search-input")?.addEventListener("input", filter);

  load();
});
