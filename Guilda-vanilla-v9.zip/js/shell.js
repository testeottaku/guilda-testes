import "./firebase.js";

export function wireShell({active}){
  // set active button in sidebar if using data-nav
  document.querySelectorAll("[data-nav]").forEach(el=>{
    const id = el.getAttribute("data-nav");
    if(id === active){
      el.classList.add("bg-emerald-50","text-emerald-700","shadow-sm");
      el.classList.remove("text-gray-500");
      const icon = el.querySelector("[data-lucide]");
      if(icon) icon.classList.add("text-emerald-600");
    }
  });

  const btnLogout = document.getElementById("btn-logout");
  if(btnLogout){
    btnLogout.addEventListener("click", async () => {
      try{ await window.__adminApi.signOut(); }catch(_){}
      try{ sessionStorage.removeItem("__session"); }catch(_){}
      window.location.href = "index.html";
    });
  }

  // mobile sidebar
  const openBtn = document.getElementById("btn-open-sidebar");
  const closeBtn = document.getElementById("btn-close-sidebar");
  const overlay = document.getElementById("sidebar-overlay");
  const sidebar = document.getElementById("sidebar");
  const show = () => {
    if(!sidebar) return;
    sidebar.classList.remove("-translate-x-full");
    if(overlay) overlay.classList.remove("hidden");
  };
  const hide = () => {
    if(!sidebar) return;
    sidebar.classList.add("-translate-x-full");
    if(overlay) overlay.classList.add("hidden");
  };
  openBtn && openBtn.addEventListener("click", show);
  closeBtn && closeBtn.addEventListener("click", hide);
  overlay && overlay.addEventListener("click", hide);

  // user info
  const roleEl = document.getElementById("user-role");
  const emailEl = document.getElementById("user-email");
  if(window.__session){
    if(roleEl) roleEl.textContent = window.__session.role === "admin" ? "Admin" : "Líder";
    if(emailEl) emailEl.textContent = window.__session.email || "—";
  }
}
