import "./firebase.js";

function el(id){ return document.getElementById(id); }
function normEmail(s){ return String(s||"").toLowerCase().trim(); }

let security = { admins: [], leaders: [] };

function renderLists(){
  el("admins-list").innerHTML = security.admins.length
    ? security.admins.map(e => `<div class="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-xl">
        <span class="text-sm text-gray-700 truncate">${e}</span>
        <button class="text-red-500 hover:text-red-600" data-remove-admin="${e}">
          <i data-lucide="x" class="w-4 h-4"></i>
        </button>
      </div>`).join("")
    : `<p class="text-sm text-gray-400">Nenhum admin definido.</p>`;

  el("leaders-list").innerHTML = security.leaders.length
    ? security.leaders.map(e => `<div class="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-xl">
        <span class="text-sm text-gray-700 truncate">${e}</span>
        <button class="text-red-500 hover:text-red-600" data-remove-leader="${e}">
          <i data-lucide="x" class="w-4 h-4"></i>
        </button>
      </div>`).join("")
    : `<p class="text-sm text-gray-400">Nenhum líder definido.</p>`;

  document.querySelectorAll("[data-remove-admin]").forEach(b=>{
    b.addEventListener("click", ()=>removeAdmin(b.getAttribute("data-remove-admin")));
  });
  document.querySelectorAll("[data-remove-leader]").forEach(b=>{
    b.addEventListener("click", ()=>removeLeader(b.getAttribute("data-remove-leader")));
  });
  lucide.createIcons();
}

async function loadSecurity(){
  try{
    security = await window.__adminApi.getSecurity();
    renderLists();
  }catch(e){
    console.error(e);
    window.__toast && window.__toast("error","Erro ao carregar security.");
  }
}

async function saveSecurity(){
  security.admins = Array.from(new Set(security.admins.map(normEmail).filter(Boolean)));
  security.leaders = Array.from(new Set(security.leaders.map(normEmail).filter(Boolean)));
  await window.__adminApi.setSecurity(security);
  await loadSecurity();
}

async function removeAdmin(email){
  security.admins = security.admins.filter(e=>e!==email);
  await saveSecurity();
  window.__toast && window.__toast("success","Admin removido.");
}

async function removeLeader(email){
  security.leaders = security.leaders.filter(e=>e!==email);
  await saveSecurity();
  window.__toast && window.__toast("success","Líder removido.");
}

async function addAdmin(){
  const email = normEmail(el("inp-add-admin").value);
  if(!email) return;
  security.admins = Array.from(new Set([...security.admins, email]));
  el("inp-add-admin").value = "";
  await saveSecurity();
  window.__toast && window.__toast("success","Admin adicionado.");
}

async function addLeader(){
  const email = normEmail(el("inp-add-leader").value);
  if(!email) return;
  security.leaders = Array.from(new Set([...security.leaders, email]));
  el("inp-add-leader").value = "";
  await saveSecurity();
  window.__toast && window.__toast("success","Líder adicionado.");
}

async function createLeaderAccount(e){
  e.preventDefault();
  const email = normEmail(el("leader-email").value);
  const pass = el("leader-pass").value;
  if(!email || !pass) return;
  try{
    await window.__adminApi.createAccount(email, pass);
    // add to leaders list
    security.leaders = Array.from(new Set([...security.leaders, email]));
    await saveSecurity();
    window.__toast && window.__toast("success","Conta criada. Faça login novamente.");
    // Creating user logs into that user; sign out and go back to login
    await window.__adminApi.signOut();
    window.location.href = "index.html";
  }catch(err){
    window.__toast && window.__toast("error", err?.message || "Falha ao criar conta.");
  }
}

async function createAdminAccount(e){
  e.preventDefault();
  const email = normEmail(el("admin-email").value);
  const pass = el("admin-pass").value;
  if(!email || !pass) return;
  try{
    await window.__adminApi.createAccount(email, pass);
    security.admins = Array.from(new Set([...security.admins, email]));
    await saveSecurity();
    window.__toast && window.__toast("success","Conta criada. Faça login novamente.");
    await window.__adminApi.signOut();
    window.location.href = "index.html";
  }catch(err){
    window.__toast && window.__toast("error", err?.message || "Falha ao criar conta.");
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  // leader-only
  if(!window.__session || window.__session.role !== "leader"){
    window.location.href = "dashboard.html";
    return;
  }

  el("btn-add-admin")?.addEventListener("click", addAdmin);
  el("btn-add-leader")?.addEventListener("click", addLeader);
  el("form-create-leader")?.addEventListener("submit", createLeaderAccount);
  el("form-create-admin")?.addEventListener("submit", createAdminAccount);

  await loadSecurity();
});
