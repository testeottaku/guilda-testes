import "./firebase.js";

function setLoading(btn, v){
  if(!btn) return;
  btn.disabled = !!v;
  btn.classList.toggle("is-loading", !!v);
}

function friendlyAuthError(err){
  const code = (err && err.code) ? String(err.code) : "";
  if(code.includes("auth/invalid-credential")) return "Email ou senha inválidos.";
  if(code.includes("auth/wrong-password")) return "Senha incorreta.";
  if(code.includes("auth/user-not-found")) return "Usuário não encontrado.";
  if(code.includes("auth/too-many-requests")) return "Muitas tentativas. Aguarde e tente novamente.";
  return (err && err.message) ? String(err.message) : "Falha no login.";
}

(async function(){
  // Se já estiver logado e autorizado, vai pro dashboard
  const res = await window.__adminApi.requireAuth({ allowRoles:["admin","leader"], redirectTo: null }).catch(()=>null);
  if(res && res.session){
    window.location.href = "dashboard.html";
    return;
  }
})();

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("login-form");
  const emailEl = document.getElementById("login-email");
  const passEl = document.getElementById("login-pass");
  const btn = document.getElementById("login-btn");

  if(!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = (emailEl?.value||"").trim();
    const pass = passEl?.value||"";
    if(!email || !pass) return;

    setLoading(btn, true);
    try{
      await window.__adminApi.signIn(email, pass);
      const s = await window.__adminApi.ensureRole();
      if(!s){
        window.__toast && window.__toast("error","Email não autorizado (não está em leaders/admins).");
        await window.__adminApi.signOut();
        setLoading(btn,false);
        return;
      }
      window.location.href = "dashboard.html";
    }catch(err){
      window.__toast && window.__toast("error", friendlyAuthError(err));
      setLoading(btn,false);
    }
  });
});
