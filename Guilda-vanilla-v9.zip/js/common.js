
      import {
        initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
      import {
        getAuth,
        onAuthStateChanged,
        signInWithEmailAndPassword,
        createUserWithEmailAndPassword,
        signOut
      } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

      import {
        getFirestore,
        collection,
        getDocs,
        setDoc,
        doc,
        deleteDoc,
        serverTimestamp,
        getDoc,
        updateDoc,
        arrayUnion,
        arrayRemove,
        query,
        where,
        limit
      } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

      const firebaseConfig = {
        apiKey: "AIzaSyA5uana2jcnWCkY3vqpotbpoQKxy7bTMtU",
        authDomain: "guilda-otk.firebaseapp.com",
        projectId: "guilda-otk",
        storageBucket: "guilda-otk.firebasestorage.app",
        messagingSenderId: "628349020809",
        appId: "1:628349020809:web:be1457404159f9ea2a3458",
        measurementId: "G-65FGV5MT0N"
      };

      const app = initializeApp(firebaseConfig);
      const db = getFirestore(app);
      const auth = getAuth(app);


      // Roles: Admin vs Líder
      const __SECURITY_DOC = doc(db, "guildConfig", "security");

      async function __getSecurity(){
        const snap = await getDoc(__SECURITY_DOC);
        const data = snap.exists() ? snap.data() : {};
        const admins = Array.isArray(data.admins) ? data.admins.map(e=>String(e).toLowerCase().trim()).filter(Boolean) : [];
        const leaders = Array.isArray(data.leaders) ? data.leaders.map(e=>String(e).toLowerCase().trim()).filter(Boolean) : [];
        return { admins, leaders };
      }

      async function __resolveRole(){
        const u = auth.currentUser;
        if(!u || !u.email) return null;
        const email = String(u.email).toLowerCase().trim();
        const sec = await __getSecurity();
        const role = sec.admins.includes(email) ? "admin" : (sec.leaders.includes(email) ? "leader" : null);
        window.__session = { email, role };
        try{ sessionStorage.setItem("__session", JSON.stringify(window.__session)); }catch(_){ }
        return window.__session;
      }

      // Auth secundário para criar contas sem deslogar o usuário atual
      const __secondaryApp = initializeApp(firebaseConfig, "secondary");
      const __secondaryAuth = getAuth(__secondaryApp);

      window.__adminApi = {
        // Apenas líder pode usar
        async createUser(email, password){
          const me = await __resolveRole();
          if(!me || me.role !== "leader") throw new Error("Apenas Líder pode criar contas.");
          const e = String(email||"").trim();
          const p = String(password||"").trim();
          if(!e || !p) throw new Error("Informe email e senha.");
          await createUserWithEmailAndPassword(__secondaryAuth, e, p);
          // limpa sessão secundária
          try{ await signOut(__secondaryAuth); }catch(_){}
          return true;
        },
        async addAdminEmail(email){
          const me = await __resolveRole();
          if(!me || me.role !== "leader") throw new Error("Apenas Líder pode adicionar Admin.");
          const e = String(email||"").toLowerCase().trim();
          if(!e) throw new Error("Informe o email.");
          await setDoc(__SECURITY_DOC, { admins: arrayUnion(e) }, { merge: true });
          return true;
        },
        async removeAdminEmail(email){
          const me = await __resolveRole();
          if(!me || me.role !== "leader") throw new Error("Apenas Líder pode remover Admin.");
          const e = String(email||"").toLowerCase().trim();
          if(!e) throw new Error("Informe o email.");
          await setDoc(__SECURITY_DOC, { admins: arrayRemove(e) }, { merge: true });
          return true;
        },
        async addLeaderEmail(email){
          const me = await __resolveRole();
          if(!me || me.role !== "leader") throw new Error("Apenas Líder pode adicionar Líder.");
          const e = String(email||"").toLowerCase().trim();
          if(!e) throw new Error("Informe o email.");
          await setDoc(__SECURITY_DOC, { leaders: arrayUnion(e) }, { merge: true });
          return true;
        },
        async removeLeaderEmail(email){
          const me = await __resolveRole();
          if(!me || me.role !== "leader") throw new Error("Apenas Líder pode remover Líder.");
          const e = String(email||"").toLowerCase().trim();
          if(!e) throw new Error("Informe o email.");
          await setDoc(__SECURITY_DOC, { leaders: arrayRemove(e) }, { merge: true });
          return true;
        },
        async listLeaders(){
          const me = await __resolveRole();
          if(!me) throw new Error("Faça login.");
          return (await __getSecurity()).leaders;
        },

        async listAdmins(){
          const me = await __resolveRole();
          if(!me) throw new Error("Faça login.");
          return (await __getSecurity()).admins;
        },
        async ensureRole(){
          return await __resolveRole();
        }
      };



      // Auth API exposta para scripts não-module (UI)
      window.__authApi = {
        signIn: (email, pass) => signInWithEmailAndPassword(auth, email, pass),
        signOut: () => signOut(auth),
        onChange: (cb) => onAuthStateChanged(auth, cb),
        currentUser: () => auth.currentUser
      };

      function __requireAuth(){
        const u = auth.currentUser;
        if(!u) throw new Error("Você precisa estar logado para acessar os dados.");
        return u;
      }

      // Store em memória (substitui localStorage por completo)
      window.__guildLS = (() => {
        const mem = Object.create(null);
        return {
          getItem: (k) => (k in mem ? mem[k] : null),
          setItem: (k, v) => { mem[k] = String(v); },
          removeItem: (k) => { delete mem[k]; }
        };
      })();

      // Toast customizado
      (function setupToast(){
        const container = document.createElement("div");
        container.id = "toast-root";
        container.style.position = "fixed";
        container.style.zIndex = "9999";
        container.style.right = "16px";
        container.style.top = "16px";
        container.style.display = "flex";
        container.style.flexDirection = "column";
        container.style.gap = "10px";
        document.body.appendChild(container);

                window.__toast = function(type, message, duration){
          const el = document.createElement("div");
          const t = (type||"info").toLowerCase();
          const isSuccess = t === "success";
          const isInfo = t === "info" || t === "warning" || t === "warn";
          const accent = isSuccess ? "rgba(16,185,129,.25)" : (isInfo ? "rgba(245,158,11,.25)" : "rgba(239,68,68,.25)");
          const dot = isSuccess ? "#10b981" : (isInfo ? "#f59e0b" : "#ef4444");

          el.style.minWidth = "240px";
          el.style.maxWidth = "340px";
          el.style.padding = "12px 14px";
          el.style.borderRadius = "14px";
          el.style.boxShadow = "0 18px 40px rgba(0,0,0,.15)";
          el.style.background = "#ffffff";
          el.style.border = "1px solid " + accent;
          el.style.fontFamily = "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial";
          el.style.color = "#111827";
          el.style.display = "flex";
          el.style.gap = "10px";
          el.style.alignItems = "flex-start";

          const bullet = document.createElement("div");
          bullet.style.width = "10px";
          bullet.style.height = "10px";
          bullet.style.borderRadius = "999px";
          bullet.style.marginTop = "5px";
          bullet.style.background = dot;

          const wrap = document.createElement("div");
          const title = document.createElement("div");
          title.style.fontWeight = "800";
          title.style.fontSize = "14px";
          title.style.lineHeight = "1.1";
          title.textContent = isSuccess ? "Sucesso" : (isInfo ? "Info" : "Erro");

          const msg = document.createElement("div");
          msg.style.marginTop = "4px";
          msg.style.fontSize = "13px";
          msg.style.color = "#374151";
          msg.style.whiteSpace = "pre-line";
          msg.textContent = String(message||"");

          wrap.appendChild(title);
          wrap.appendChild(msg);

          el.appendChild(bullet);
          el.appendChild(wrap);
          container.appendChild(el);

          const ms = Number(duration||2500);
          setTimeout(()=>{ 
            el.style.opacity = "0";
            el.style.transform = "translateY(-6px)";
            el.style.transition = "all .25s ease";
            setTimeout(()=>{ try{container.removeChild(el);}catch(e){} }, 260);
          }, ms);
        };
      })();

      // Firestore API (coleção: "membros")
      window.__guildDB = {
        async getMembers(){
          const snap = await getDocs(collection(db, "membros"));
          const arr = [];
          snap.forEach(d => {
            const data = d.data() || {};
            // garante id
            arr.push({ id: d.id, ...data, id: d.id });
          });
          // ordena por nick (opcional)
          arr.sort((a,b)=> String(a.nick||"").localeCompare(String(b.nick||""), "pt-BR"));
          return arr;
        },
        async addMember(member){
          const clean = { ...member };
          // remove data de entrada se vier por acaso
          delete clean.joinDate;

          // aplica/remover tag opcional
          const _rawNick = String(clean.nick||"").replace(/^ᵒᵗᵏ\s+/i,"").replace(/^otk\s+/i,"").trim();
          if(clean.hasTag){ clean.nick = "ᵒᵗᵏ " + _rawNick; } else { clean.nick = _rawNick; }

          // bloqueia ID do jogador duplicado (visibleId)
          const vid = String(clean.visibleId||"").trim();
          if(!vid) throw new Error("Informe o ID do jogador.");
          const q = query(collection(db, "membros"), where("visibleId", "==", vid), limit(1));
          const snap = await getDocs(q);
          if(!snap.empty) throw new Error("Esse ID já existe. Não é possível adicionar repetido.");

          clean.updatedAt = serverTimestamp();
          await setDoc(doc(db, "membros", clean.id), clean, { merge: true });
        },
        async updateMember(id, patch){
          const clean = { ...patch };
          delete clean.joinDate;

          // aplica/remover tag opcional
          const _rawNick = String(clean.nick||"").replace(/^ᵒᵗᵏ\s+/i,"").replace(/^otk\s+/i,"").trim();
          if(clean.hasTag){ clean.nick = "ᵒᵗᵏ " + _rawNick; } else { clean.nick = _rawNick; }

          // se estiver alterando o ID visível, valida duplicidade
          if(typeof clean.visibleId !== "undefined"){
            const vid = String(clean.visibleId||"").trim();
            if(!vid) throw new Error("Informe o ID do jogador.");
            const q = query(collection(db, "membros"), where("visibleId", "==", vid), limit(5));
            const snap = await getDocs(q);
            const conflict = snap.docs.find(d => d.id !== id);
            if(conflict) throw new Error("Esse ID já existe. Não é possível duplicar.");
          }

          clean.updatedAt = serverTimestamp();
          await setDoc(doc(db, "membros", id), clean, { merge: true });
        },
        async deleteMember(id){
          await deleteDoc(doc(db, "membros", id));
        }
      };

      // Remove campo "Data de Entrada" visualmente (garantia extra, sem depender do bundle)
      (function hideJoinDateField(){
        const kill = () => {
          const labels = Array.from(document.querySelectorAll("label"));
          labels.forEach(l => {
            if ((l.textContent || "").trim() === "Data de Entrada") {
              const wrap = l.closest("div");
              if (wrap) wrap.remove();
            }
          });
        };
        new MutationObserver(kill).observe(document.documentElement, { childList: true, subtree: true });
      })();
    

      // Atualiza role ao mudar sessão (e garante menu correto)
      onAuthStateChanged(auth, async (u) => {
        try{
          if(u){
            const s = await window.__adminApi.ensureRole();
            if(!s || !s.role){
              try{ window.__toast && window.__toast("error","Email não autorizado (não está em leaders/admins)."); }catch(_){}
              try{ sessionStorage.removeItem("__session"); }catch(_){}
              try{ await signOut(auth); }catch(_){}
              return;
            }
            // Debug leve
            try{ window.__toast && window.__toast("success","Perfil: "+s.role+" • "+s.email, 3000); }catch(_){}

            // Garante que o app renderize com o role correto (evita só Dashboard)
            try{
              const k="__role_boot";
              if(sessionStorage.getItem(k)!=="1"){
                sessionStorage.setItem(k,"1");
                location.reload();
              }
            }catch(_){}
          }else{
            window.__session = null;
            try{ sessionStorage.removeItem("__session"); sessionStorage.removeItem("__role_boot"); }catch(_){}
          }
        }catch(e){
          try{ window.__toast && window.__toast("error","Falha ao validar perfil."); }catch(_){}
        }
      });


      (function(){ var y=document.getElementById("otk-year"); if(y) y.textContent=new Date().getFullYear(); })();
    
