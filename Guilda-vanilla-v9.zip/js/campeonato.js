import "./firebase.js";

function getCamps(){
  return Array.isArray(window.__guildCamps) ? window.__guildCamps : (window.__guildCamps = []);
}
function setCamps(v){
  window.__guildCamps = Array.isArray(v) ? v : [];
}

let editing = null;

function el(id){ return document.getElementById(id); }

function render(){
  const list = el("camps-list");
  const camps = getCamps();
  if(!camps.length){
    list.innerHTML = `<div class="bg-white rounded-2xl p-8 border border-gray-100 text-center text-gray-400">Nenhum campeonato criado.</div>`;
    lucide.createIcons();
    return;
  }
  list.innerHTML = camps.map(c => `
    <div class="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <h3 class="text-lg font-bold text-gray-900 truncate">${c.name}</h3>
          <p class="text-gray-500 text-sm mt-1">${c.description || "—"}</p>
        </div>
        <div class="flex gap-2">
          <button class="px-3 py-2 rounded-xl bg-emerald-100 text-emerald-700 text-sm font-medium hover:bg-emerald-200" data-edit="${c.id}">
            <i data-lucide="pencil" class="w-4 h-4"></i>
          </button>
          <button class="px-3 py-2 rounded-xl bg-red-100 text-red-700 text-sm font-medium hover:bg-red-200" data-del="${c.id}">
            <i data-lucide="trash-2" class="w-4 h-4"></i>
          </button>
        </div>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Data</p>
          <div class="text-sm font-semibold text-gray-900">${c.date || "—"}</div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Horário</p>
          <div class="text-sm font-semibold text-gray-900">${c.time || "—"}</div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Local</p>
          <div class="text-sm font-semibold text-gray-900 truncate">${c.location || "—"}</div>
        </div>
        <div class="bg-white rounded-xl p-3 border border-gray-100">
          <p class="text-xs text-gray-400 mb-1">Status</p>
          <div class="text-sm font-semibold text-gray-900">${c.status || "upcoming"}</div>
        </div>
      </div>
    </div>
  `).join("");

  list.querySelectorAll("[data-edit]").forEach(b=>{
    b.addEventListener("click", ()=>openModal(b.getAttribute("data-edit")));
  });
  list.querySelectorAll("[data-del]").forEach(b=>{
    b.addEventListener("click", ()=>delCamp(b.getAttribute("data-del")));
  });
  lucide.createIcons();
}

function openModal(id=null){
  editing = id;
  const camps = getCamps();
  const c = id ? camps.find(x=>x.id===id) : null;
  el("modal-title").textContent = id ? "Editar Campeonato" : "Novo Campeonato";
  el("inp-name").value = c?.name || "";
  el("inp-description").value = c?.description || "";
  el("inp-date").value = c?.date || "";
  el("inp-time").value = c?.time || "";
  el("inp-location").value = c?.location || "";
  el("inp-max").value = Number(c?.maxParticipants ?? 30);
  el("inp-status").value = c?.status || "upcoming";
  el("modal").classList.remove("hidden");
  lucide.createIcons();
}
function closeModal(){
  el("modal").classList.add("hidden");
  editing=null;
}

function uid(){
  return Date.now().toString(36)+Math.random().toString(36).slice(2,9);
}

function save(e){
  e.preventDefault();
  const data = {
    id: editing || uid(),
    name: el("inp-name").value.trim(),
    description: el("inp-description").value.trim(),
    date: el("inp-date").value,
    time: el("inp-time").value,
    location: el("inp-location").value.trim(),
    maxParticipants: Number(el("inp-max").value || 30),
    status: el("inp-status").value
  };
  if(!data.name){
    window.__toast && window.__toast("error","Informe o nome.");
    return;
  }
  const camps = getCamps();
  const next = editing ? camps.map(c=>c.id===editing?data:c) : [data, ...camps];
  setCamps(next);
  window.__toast && window.__toast("success", editing ? "Atualizado!" : "Criado!");
  closeModal();
  render();
}

function delCamp(id){
  if(!confirm("Excluir este campeonato?")) return;
  setCamps(getCamps().filter(c=>c.id!==id));
  window.__toast && window.__toast("success","Excluído!");
  render();
}

document.addEventListener("DOMContentLoaded", async () => {
  // leader-only
  if(!window.__session || window.__session.role !== "leader"){
    window.location.href = "dashboard.html";
    return;
  }
  el("btn-add")?.addEventListener("click", ()=>openModal(null));
  el("btn-close-modal")?.addEventListener("click", closeModal);
  el("modal-overlay")?.addEventListener("click", closeModal);
  el("camp-form")?.addEventListener("submit", save);
  render();
});
